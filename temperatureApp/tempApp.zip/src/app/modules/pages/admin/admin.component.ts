import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthService} from '../../shared/services/auth/auth.service';
import { UserService, User } from '../../shared/services/user/user.service';

@Component({
  selector: 'app-admin',
  providers: [ UserService ],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  private listeUsers: User[];
  private ygy: Object;

  constructor(public authService: AuthService, public router: Router, private userService: UserService) {}

  ngOnInit() {
    setInterval(() => {
      this.userService.getUser().subscribe(data => {
      this.listeUsers = data
      }) 
      }, 1000);
  }

  delete(id) {
    //this.userService.delUser(id);
    this.userService.delUser(id).subscribe(data => {
      this.ygy = data;
    });
  }
}
