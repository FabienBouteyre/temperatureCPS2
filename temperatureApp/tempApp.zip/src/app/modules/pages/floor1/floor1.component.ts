import { Component,  OnInit, Input, ViewChild  } from '@angular/core';
import { projection } from 'devextreme/viz/vector_map/projection';
import { Observable } from 'rxjs';
import { Temperature } from '../../shared/services/temperature/temperature';
import { FeatureCollection, Feature, TemperatureService } from '../../shared/services/temperature/temperature.service';



@Component({
  selector: 'app-floor1',
  providers: [ TemperatureService ],
  templateUrl: './floor1.component.html',
  styleUrls: ['./floor1.component.css']
})
export class Floor1Component implements OnInit {

  private projection: any;
  private roomsData: FeatureCollection;
  private buildingData: FeatureCollection;
  private listeTemperatures: Temperature[];
  private elem:any;

  constructor(private temperatureService: TemperatureService) {
  }
  
  ngOnInit() {
    this.roomsData = this.temperatureService.getRoomsDataFloor1();
    this.customizeLayers = this.customizeLayers.bind(this);
    this.customizeTooltip = this.customizeTooltip.bind(this);
    this.buildingData = this.temperatureService.getBuildingData();
    this.projection = projection({
      to: function (coordinates) {
        return [coordinates[0] / 100, coordinates[1] / 100];
      }, from: function (coordinates) {
              return [coordinates[0] * 100, coordinates[1] * 100];
          }
    });
    
    setInterval(() => {  
      this.temperatureService.getTemperature().subscribe(data => {
      this.listeTemperatures = data;
      }); 
      this.customizeLayers(this.elem);
      }, 1000);
  }

  getValue(room: string): string{
    try {
      for(var i=0;this.listeTemperatures.length;i++){
        if(this.listeTemperatures[i].room==room){
          return this.listeTemperatures[i].sensorDataEntity.temp;
        }
      }
    } catch (error) {
      return error
    }
    
  }
  getLight(room: string): string{
    try {
      for(var i=0;this.listeTemperatures.length;i++){
        if(this.listeTemperatures[i].room==room){
          return this.listeTemperatures[i].sensorDataEntity.light;
        }
      }
    } catch (error) {
      return error
    }
    
  }
  getHmdt(room: string): string{
    try {
      for(var i=0;this.listeTemperatures.length;i++){
        if(this.listeTemperatures[i].room==room){
          return this.listeTemperatures[i].sensorDataEntity.hmdt;
        }
      }
    } catch (error) {
      return error
    }
    
  }
  getDescrib(room: string): string{
    for(var i=0;this.listeTemperatures.length;i++){
      if(this.listeTemperatures[i].room==room){
        return this.listeTemperatures[i].describ;
      }
    }
    return ""
  }

  customizeTooltip(arg) {
    if(arg.layer.name === "rooms"){
      if(this.listeTemperatures != undefined){
        try {
          return {
            html: "Temperature : "+this.getValue(arg.attribute("name"))+"°C"+"<br>"+
                  "Humidity : "+this.getHmdt(arg.attribute("name"))+"<br>"+
                  "Light : "+this.getLight(arg.attribute("name"))+"<br>"+"<br>"+
                  this.getDescrib(arg.attribute("name"))
        };
        } catch (error) {
          return {
            html: "No information"
        };
        }
      }
    }  
  }
  customizeLayers(elements) {
    this.elem = elements;

    elements.forEach((element) => {
      //console.log(element.attribute("name"))
      //console.log(element.attribute("value"))
      //console.log(this.getValue(element.attribute("name")))
      if(this.listeTemperatures != undefined){
        try {
          // console.log(element.attribute("name"))
          // element.attribute("value", element.attribute("name")+"<br>"+this.getValue(element.attribute("name")));
          // element.attribute("value","test")
        } catch (error) {
          //console.log("Pas bon")
          element.attribute("value", "?");
        }
      }

      // if(element.attribute("value") == "?" || element.attribute("value") == "WC"){
      //   element.applySettings({
      //     color: "#808080"
      // });
      // }
      // else if(parseInt(element.attribute("value"))>30){
      //   element.applySettings({
      //     color: "#B22222"
      // });
      // } else if (parseInt(element.attribute("value"))<15){
      //   element.applySettings({
      //     color: "#4169E1"
      // });
      // } else if (parseInt(element.attribute("value"))>=15 || parseInt(element.attribute("value"))<=30) {
      //   element.applySettings({
      //     color: "#008000"
      // });
      // }
    
  });
    
  }
}