import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DxVectorMapModule } from 'devextreme-angular';

import { AppRoutingModule } from './routing/app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { Floor1Component } from './modules/pages/floor1/floor1.component';
import { Floor2Component } from './modules/pages/floor2/floor2.component';
import { AdminComponent } from './modules/pages/admin/admin.component';
import { LoginComponent } from './modules/shared/login/login.component';
import { LoginRoutingModule } from './modules/shared/login/login-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    Floor1Component,
    Floor2Component,
    AdminComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    DxVectorMapModule,
    HttpClientModule,
    AppRoutingModule,
    LoginRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
