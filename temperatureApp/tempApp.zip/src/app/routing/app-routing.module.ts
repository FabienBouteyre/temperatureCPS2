import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Floor1Component } from '../modules/pages/floor1/floor1.component';
import { Floor2Component } from '../modules/pages/floor2/floor2.component';
import { AdminComponent } from '../modules/pages/admin/admin.component';
import { AuthGuard } from '../modules/shared/services/auth/auth-guard.service';
import { LoginComponent } from '../modules/shared/login/login.component';

const routes: Routes = [
	{ path: 'floor1', component: Floor1Component},
  { path: 'floor2', component: Floor2Component},
  { path: 'admin', component: AdminComponent}, //, canActivate: [AuthGuard]
  { path: 'login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
